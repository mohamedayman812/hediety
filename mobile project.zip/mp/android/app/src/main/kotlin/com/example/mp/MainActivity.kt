package com.example.mp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
