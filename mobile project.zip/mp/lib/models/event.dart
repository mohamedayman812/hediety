class Event {
  int? id;
  String name;
  String date;
  String location;
  String description;
  int userId;

  Event({this.id, required this.name, required this.date, required this.location, required this.description, required this.userId});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'date': date,
      'location': location,
      'description': description,
      'user_id': userId,
    };
  }

  factory Event.fromMap(Map<String, dynamic> map) {
    return Event(
      id: map['id'],
      name: map['name'],
      date: map['date'],
      location: map['location'],
      description: map['description'],
      userId: map['user_id'],
    );
  }
}
