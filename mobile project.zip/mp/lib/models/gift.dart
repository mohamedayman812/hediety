class Gift {
  final String id;
  final String name;
  final String description;
  final String category;
  final double price;
  final String status;

  Gift({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.price,
    required this.status,
  });

  factory Gift.fromFirestore(String id, Map<String, dynamic> data) {
    return Gift(
      id: id,
      name: data['name'],
      description: data['description'],
      category: data['category'],
      price: data['price'],
      status: data['status'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'category': category,
      'price': price,
      'status': status,
    };
  }
}
