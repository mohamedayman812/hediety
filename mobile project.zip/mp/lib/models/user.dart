class User {
  int? id;
  String name;
  String email;
  String phoneNumber;
  String preferences;

  User({
    this.id,
    required this.name,
    required this.email,
    required this.phoneNumber,
    required this.preferences,
  });

  /// Convert User object to a map for Firestore or other storage
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phoneNumber': phoneNumber,
      'preferences': preferences,
    };
  }

  /// Factory constructor to create User object from a map
  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'],
      name: map['name'],
      email: map['email'],
      phoneNumber: map['phoneNumber'],
      preferences: map['preferences'],
    );
  }
}
