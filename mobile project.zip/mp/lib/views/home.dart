import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'profile.dart'; // Profile Page
import 'eventList.dart'; // My Events Page
import 'giftList.dart'; // Gift Screen

class HomePage extends StatefulWidget {
  final String userId;

  const HomePage({super.key, required this.userId});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _searchQuery = "";

  void _addFriendDialog(BuildContext context, User? currentUser) {
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Add Friend by Phone Number'),
          content: TextField(
            controller: phoneController,
            decoration: const InputDecoration(labelText: 'Enter Phone Number'),
            keyboardType: TextInputType.phone,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                final phone = phoneController.text.trim();

                if (phone.isNotEmpty && currentUser != null) {
                  if (phone == currentUser.phoneNumber) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('You cannot add your own phone number.')),
                    );
                    Navigator.pop(context);
                    return;
                  }

                  try {
                    final querySnapshot = await FirebaseFirestore.instance
                        .collection('users')
                        .where('phone', isEqualTo: phone)
                        .get();

                    if (querySnapshot.docs.isNotEmpty) {
                      final friendData = querySnapshot.docs.first;
                      final friendId = friendData.id;

                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(currentUser.uid)
                          .update({
                        'friends': FieldValue.arrayUnion([friendId]),
                      });

                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            content: Text(
                                'Friend ${friendData['username']} added successfully!')),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('No user found with this phone number.')),
                      );
                    }
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Error: $e')),
                    );
                  }
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Phone number cannot be empty.')),
                  );
                }
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  void _deleteFriend(BuildContext context, String friendId, String userId) async {
    try {
      await FirebaseFirestore.instance.collection('users').doc(userId).update({
        'friends': FieldValue.arrayRemove([friendId]),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Friend removed successfully!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    User? user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('No user is logged in.')),
      );
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal, Colors.lightBlueAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 10),

              // Fetch the user's name from Firestore
              StreamBuilder<DocumentSnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .doc(user.uid)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  final userData = snapshot.data!.data() as Map<String, dynamic>?;

                  final username = userData?['username'] ?? 'User';

                  return Text(
                    'Welcome $username',
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
                  );
                },
              ),

              const SizedBox(height: 20),

              // Search Bar
              TextField(
                onChanged: (query) {
                  setState(() {
                    _searchQuery = query.toLowerCase();
                  });
                },
                decoration: const InputDecoration(
                  hintText: "Search for a friend...",
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 20),

              // Friends List Section
              Expanded(
                child: StreamBuilder<DocumentSnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('users')
                      .doc(user.uid)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    final userData = snapshot.data!.data() as Map<String, dynamic>?;

                    final friendsList = userData?['friends'] as List<dynamic>? ?? [];

                    if (friendsList.isEmpty) {
                      return const Center(child: Text('No friends found.'));
                    }

                    return ListView.builder(
                      itemCount: friendsList.length,
                      itemBuilder: (context, index) {
                        final friendId = friendsList[index];
                        return FutureBuilder<DocumentSnapshot>(
                          future: FirebaseFirestore.instance
                              .collection('users')
                              .doc(friendId)
                              .get(),
                          builder: (context, friendSnapshot) {
                            if (!friendSnapshot.hasData) {
                              return const Center(child: CircularProgressIndicator());
                            }

                            final friendData = friendSnapshot.data!.data() as Map<String, dynamic>;
                            final friendName = friendData['username'] ?? 'Unknown';
                            final friendPhone = friendData['phone'] ?? 'No phone';

                            // If the friend's name contains the search query, show the friend
                            if (_searchQuery.isNotEmpty && !friendName.toLowerCase().contains(_searchQuery)) {
                              return Container();
                            }

                            // Fetch and filter upcoming events for the friend
                            final events = friendData['events'] as List<dynamic>? ?? [];
                            final upcomingEvents = events.where((event) {
                              final eventDate = DateTime.tryParse(event['eventDate'] ?? '');
                              return eventDate != null && eventDate.isAfter(DateTime.now());
                            }).toList();

                            return Card(
                              margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                              child: ListTile(
                                title: Text(friendName),
                                leading: const CircleAvatar(
                                  child: Icon(Icons.person),
                                ),
                                trailing: IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red),
                                  onPressed: () => _deleteFriend(context, friendId, user.uid),
                                ),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => EventsPage(userId: friendId),
                                    ),
                                  );
                                },
                                isThreeLine: true,
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Phone: $friendPhone'),
                                    const SizedBox(height: 5),
                                    Text('Upcoming Events: ${upcomingEvents.length}'),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addFriendDialog(context, user),
        tooltip: 'Add Friend',
        child: const Icon(Icons.add),
        backgroundColor: Colors.teal,
      ),
      bottomNavigationBar: BottomAppBar(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ProfilePage(userId: user.uid)),
                  );
                },
                icon: const Icon(Icons.person),
                label: const Text('Profile'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => EventsPage(userId: user.uid)),
                  );
                },
                icon: const Icon(Icons.event),
                label: const Text('Events'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
