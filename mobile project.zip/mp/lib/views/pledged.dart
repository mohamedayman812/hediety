import 'package:flutter/material.dart';

class PledgedGiftsscreen extends StatefulWidget {
  @override
  _PledgedGiftsscreenState createState() => _PledgedGiftsscreenState();
}

class _PledgedGiftsscreenState extends State<PledgedGiftsscreen> {
  final List<PledgedGift> pledgedGifts = [
    PledgedGift('Laptop', 'Ahmed Ali', '2024-12-11', true),
    PledgedGift('PC', 'Yahya Sharaf', '2024-12-12', false),
    PledgedGift('Book', 'Sherwet Mohamed', '2024-12-13', true),
    PledgedGift('Perfume', 'Adham Hatem', '2024-12-14', false),
    PledgedGift('Clothes', 'Samir Eladl', '2024-12-15', true),
  ];

  /// Handle edit action
  void _editPledgedGift(PledgedGift gift) {
    TextEditingController nameController =
    TextEditingController(text: gift.giftName);
    TextEditingController friendController =
    TextEditingController(text: gift.friendName);
    TextEditingController dateController =
    TextEditingController(text: gift.dueDate);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Pledged Gift'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Gift Name'),
              ),
              TextField(
                controller: friendController,
                decoration: const InputDecoration(labelText: 'Friend Name'),
              ),
              TextField(
                controller: dateController,
                decoration: const InputDecoration(labelText: 'Due Date'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  gift.giftName = nameController.text;
                  gift.friendName = friendController.text;
                  gift.dueDate = dateController.text;
                });
                Navigator.pop(context);
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  /// Handle delete action
  void _deletePledgedGift(PledgedGift gift) {
    setState(() {
      pledgedGifts.remove(gift);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${gift.giftName} has been removed.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Pledged Gifts'),
        backgroundColor: Colors.teal,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal, Colors.lightBlueAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: ListView.builder(
          padding: const EdgeInsets.all(10),
          itemCount: pledgedGifts.length,
          itemBuilder: (context, index) {
            final gift = pledgedGifts[index];
            return Card(
              elevation: 5,
              margin: const EdgeInsets.symmetric(vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.all(16),
                title: Text(
                  gift.giftName,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                subtitle: Text(
                  'For: ${gift.friendName}\nDue: ${gift.dueDate}',
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ),
                trailing: gift.isPending
                    ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon:
                      const Icon(Icons.edit, color: Colors.blueAccent),
                      onPressed: () => _editPledgedGift(gift),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deletePledgedGift(gift),
                    ),
                  ],
                )
                    : const Icon(Icons.check_circle,
                    color: Colors.green, size: 30),
              ),
            );
          },
        ),
      ),
    );
  }
}

class PledgedGift {
  String giftName;
  String friendName;
  String dueDate;
  bool isPending;

  PledgedGift(this.giftName, this.friendName, this.dueDate, this.isPending);
}
