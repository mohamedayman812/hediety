import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'login.dart';

class ProfilePage extends StatelessWidget {
  final String userId;

  const ProfilePage({super.key, required this.userId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(" My Profile"),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Container(
        decoration: const BoxDecoration(
          color: Colors.teal, // Set the background color to teal
        ),
        child: FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance.collection('users').doc(userId).get(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return const Center(child: Text("Error loading profile."));
            }

            if (!snapshot.hasData || !snapshot.data!.exists) {
              return const Center(child: Text("User data not found."));
            }

            // Get the user data from Firestore
            final userData = snapshot.data!.data() as Map<String, dynamic>;
            final username = userData['username'] ?? 'Unknown';
            final email = userData['email'] ?? 'Not available';
            final phone = userData['phone'] ?? 'Not available';
            final profileImage = userData['profileImage'] ?? ''; // Add a profile image if available

            return Padding(
              padding: const EdgeInsets.all(20.0),
              child: Center(
                child: ListView(
                  children: [
                    // Profile Image at the top with normal size
                    CircleAvatar(
                      radius: 90, // Normal size for the profile image
                      backgroundImage: NetworkImage(profileImage.isEmpty
                          ? ''
                          : profileImage),
                    ),
                    const SizedBox(height: 30),

                    // Title for Profile Information
                    const Text(
                      "Profile Information",
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Username TextFormField (Non-editable)
                    Row(
                      children: const [
                        Text(
                          "Username: ",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: TextFormField(
                        initialValue: username,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                        ),
                        enabled: false,
                        style: const TextStyle(fontSize: 18),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Email TextFormField (Non-editable)
                    Row(
                      children: const [
                        Text(
                          "Email: ",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: TextFormField(
                        initialValue: email,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                        ),
                        enabled: false,
                        style: const TextStyle(fontSize: 18),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Phone Number TextFormField (Non-editable)
                    Row(
                      children: const [
                        Text(
                          "Phone Number: ",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: TextFormField(
                        initialValue: phone,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                        ),
                        enabled: false,
                        style: const TextStyle(fontSize: 18),
                      ),
                    ),
                    const SizedBox(height: 30),

                    // App Overview Section - Now in Expandable List
                    ExpansionTile(
                      title: const Text(
                        "App Overview",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      children: const [
                        ListTile(
                          title: Text(
                            "This app helps you manage your health and lifestyle by providing tailored meal plans and workout routines. Stay fit, stay healthy!",
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // FAQ Section - Now in Expandable List
                    ExpansionTile(
                      title: const Text(
                        "FAQ",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      children: [
                        ListTile(
                          title: const Text(
                            "Q1: How do I update my profile?\nA1: You can update your profile from the settings page.",
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                        ListTile(
                          title: const Text(
                            "Q2: How do I track my meals?\nA2: You can log your meals under the 'Nutrition' section.",
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),

                    // Logout Button with consistent width
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          // Log out the user
                          await FirebaseAuth.instance.signOut();
                          // Navigate to the login page after logout
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (context) => const Login()),
                          );
                        },
                        icon: const Icon(Icons.exit_to_app, color: Colors.white),
                        label: const Text('Logout', style: TextStyle(color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          padding: const EdgeInsets.symmetric(vertical: 16.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
