import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'login.dart'; // Login page after sign up
import 'package:mp/models/cologo.dart'; // Import your CustomLogoAuth widget

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  bool _isLoading = false;

  void _registerUser() async {
    if (_emailController.text.trim().isEmpty || _passwordController.text.trim().isEmpty || _usernameController.text.trim().isEmpty || _phoneController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("All fields are required.")));
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      // Save user information to Firestore
      await FirebaseFirestore.instance.collection('users').doc(userCredential.user!.uid).set({
        'username': _usernameController.text.trim(),
        'email': _emailController.text.trim(),
        'phone': _phoneController.text.trim(),
      });

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Registration Successful!")));

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const Login(), // Redirect to Login page after successful signup
        ),
      );
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? "An error occurred")));
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Background gradient
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal, Colors.lightBlueAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Add the logo widget
                const CustomLogoAuth(), // Add this line to display the logo

                const SizedBox(height: 30),

                // App name
                const Text(
                  'Hediety',
                  style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 30),

                // Welcome text
                const Text(
                  'Create Your Account',
                  style: TextStyle(fontSize: 24, color: Colors.white),
                ),
                const SizedBox(height: 40),

                // Username TextField
                TextFormField(
                  controller: _usernameController,
                  decoration: InputDecoration(
                    labelText: 'Username',
                    hintText: 'Enter your username',
                    filled: true, // Make the background transparent
                    fillColor: Colors.transparent, // Transparent background
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: Colors.white), // White border
                    ),
                    prefixIcon: const Icon(Icons.person, color: Colors.teal),
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)), // Light hint text
                    labelStyle: TextStyle(color: Colors.white.withOpacity(0.7)), // Label color
                  ),
                ),
                const SizedBox(height: 20),

                // Email TextField
                TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    hintText: 'Enter your email',
                    filled: true, // Make the background transparent
                    fillColor: Colors.transparent, // Transparent background
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: Colors.white), // White border
                    ),
                    prefixIcon: const Icon(Icons.email, color: Colors.teal),
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)), // Light hint text
                    labelStyle: TextStyle(color: Colors.white.withOpacity(0.7)), // Label color
                  ),
                ),
                const SizedBox(height: 20),

                // Phone Number TextField
                TextFormField(
                  controller: _phoneController,
                  decoration: InputDecoration(
                    labelText: 'Phone Number',
                    hintText: 'Enter your phone number',
                    filled: true, // Make the background transparent
                    fillColor: Colors.transparent, // Transparent background
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: Colors.white), // White border
                    ),
                    prefixIcon: const Icon(Icons.phone, color: Colors.teal),
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)), // Light hint text
                    labelStyle: TextStyle(color: Colors.white.withOpacity(0.7)), // Label color
                  ),
                ),
                const SizedBox(height: 20),

                // Password TextField
                TextFormField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    hintText: 'Enter your password',
                    filled: true, // Make the background transparent
                    fillColor: Colors.transparent, // Transparent background
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: Colors.white), // White border
                    ),
                    prefixIcon: const Icon(Icons.lock, color: Colors.teal),
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)), // Light hint text
                    labelStyle: TextStyle(color: Colors.white.withOpacity(0.7)), // Label color
                  ),
                ),
                const SizedBox(height: 30),

                // Sign Up Button with teal background and same width as TextField
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _registerUser,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal, // Set button background color to teal
                      padding: const EdgeInsets.symmetric(vertical: 16.0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text(
                      'Sign Up',
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Login navigation text
                TextButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const Login()), // Navigate to Login page if already have account
                    );
                  },
                  child: const Text(
                    "Already have an account? Login",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
