import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class GiftScreen extends StatefulWidget {
  final String userId; // ID of the user whose gifts are being viewed
  final String currentUserId; // ID of the currently logged-in user
  final int eventIndex;
  final List<dynamic> gifts;

  const GiftScreen({
    Key? key,
    required this.userId,
    required this.currentUserId,
    required this.eventIndex,
    required this.gifts,
  }) : super(key: key);

  @override
  _GiftScreenState createState() => _GiftScreenState();
}

class _GiftScreenState extends State<GiftScreen> {
  final TextEditingController _giftNameController = TextEditingController();
  final TextEditingController _giftDescriptionController = TextEditingController();
  final TextEditingController _giftCategoryController = TextEditingController();
  final TextEditingController _giftPriceController = TextEditingController();

  // Show dialog to add a new gift
  void _showAddGiftDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Add Gift"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _giftNameController,
                decoration: const InputDecoration(labelText: 'Gift Name'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _giftDescriptionController,
                decoration: const InputDecoration(labelText: 'Gift Description'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _giftCategoryController,
                decoration: const InputDecoration(labelText: 'Gift Category'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _giftPriceController,
                decoration: const InputDecoration(labelText: 'Gift Price'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () => _addGift(context),
              child: const Text("Add Gift"),
            ),
          ],
        );
      },
    );
  }

  // Add a new gift
  void _addGift(BuildContext context) async {
    final giftName = _giftNameController.text.trim();
    final giftDescription = _giftDescriptionController.text.trim();
    final giftCategory = _giftCategoryController.text.trim();
    final giftPrice = double.tryParse(_giftPriceController.text.trim());

    if (giftName.isEmpty || giftDescription.isEmpty || giftCategory.isEmpty || giftPrice == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill in all fields correctly.")),
      );
      return;
    }

    try {
      final doc = FirebaseFirestore.instance.collection('users').doc(widget.userId);
      final snapshot = await doc.get();

      // Get the events and the target event
      final events = List<dynamic>.from(snapshot['events']);
      final event = events[widget.eventIndex];

      // Add a new gift tagged with the current user's ID
      final gifts = List<dynamic>.from(event['gifts'] ?? []);
      gifts.add({
        'name': giftName,
        'description': giftDescription,
        'category': giftCategory,
        'price': giftPrice,
        'status': 'available',
        'ownerId': widget.currentUserId,
      });

      event['gifts'] = gifts;
      events[widget.eventIndex] = event;

      // Update Firestore
      await doc.update({'events': events});

      setState(() {
        widget.gifts.add({
          'name': giftName,
          'description': giftDescription,
          'category': giftCategory,
          'price': giftPrice,
          'status': 'available',
          'ownerId': widget.currentUserId,
        });
      });

      _giftNameController.clear();
      _giftDescriptionController.clear();
      _giftCategoryController.clear();
      _giftPriceController.clear();
      Navigator.pop(context); // Close dialog
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gift added successfully!")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  // Pledge a gift
  void _pledgeGift(int index) async {
    final gift = widget.gifts[index];
    if (gift['status'] == 'available' && gift['ownerId'] != widget.currentUserId) {
      try {
        final doc = FirebaseFirestore.instance.collection('users').doc(widget.userId);
        final snapshot = await doc.get();
        final events = List<dynamic>.from(snapshot['events']);
        final event = events[widget.eventIndex];
        final gifts = List<dynamic>.from(event['gifts']);

        // Update the gift's status to 'pledged' and set the current user's ID as the one who pledged
        gifts[index] = {
          'name': gift['name'],
          'description': gift['description'],
          'category': gift['category'],
          'price': gift['price'],
          'status': 'pledged',
          'ownerId': gift['ownerId'],
          'pledgedBy': widget.currentUserId, // Add the user who pledged the gift
        };

        event['gifts'] = gifts;
        events[widget.eventIndex] = event;

        // Update Firestore
        await doc.update({'events': events});

        setState(() {
          widget.gifts[index] = {
            'name': gift['name'],
            'description': gift['description'],
            'category': gift['category'],
            'price': gift['price'],
            'status': 'pledged',
            'ownerId': gift['ownerId'],
            'pledgedBy': widget.currentUserId,
          };
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Gift pledged successfully!")),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: $e")),
        );
      }
    } else if (gift['ownerId'] == widget.currentUserId) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("You cannot pledge your own gift.")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("This gift has already been pledged.")),
      );
    }
  }

  // Edit a gift
  void _editGift(int index) async {
    final gift = widget.gifts[index];
    if (gift['status'] == 'available' && gift['ownerId'] == widget.currentUserId) {
      // Show dialog to edit the gift
      _giftNameController.text = gift['name'];
      _giftDescriptionController.text = gift['description'];
      _giftCategoryController.text = gift['category'];
      _giftPriceController.text = gift['price'].toString();

      _showAddGiftDialog(context); // Reuse the add gift dialog for editing
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("You can only edit your own available gifts.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Gifts"),
        backgroundColor: Colors.teal,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal, Colors.blueAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(10.0),
        child: ListView.builder(
          itemCount: widget.gifts.length,
          itemBuilder: (context, index) {
            final gift = widget.gifts[index];
            final giftName = gift['name'] ?? "Unnamed Gift";
            final giftDescription = gift['description'] ?? "No Description";
            final giftCategory = gift['category'] ?? "No Category";
            final giftPrice = gift['price']?.toStringAsFixed(2) ?? "No Price";
            final giftStatus = gift['status'] ?? "available";

            return Card(
              margin: const EdgeInsets.all(8.0),
              elevation: 5, // Add shadow for the card
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0), // Rounded corners
              ),
              child: ListTile(
                leading: Icon(
                  Icons.card_giftcard, // Gift icon
                  color: giftStatus == 'available' ? Colors.green : Colors.grey,
                ),
                title: Text(
                  giftName,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                    "$giftDescription\nCategory: $giftCategory\nPrice: \$${giftPrice}\nStatus: $giftStatus"),
                trailing: giftStatus == 'available'
                    ? gift['ownerId'] == widget.currentUserId
                    ? IconButton(
                  icon: const Icon(Icons.edit, color: Colors.blue),
                  onPressed: () => _editGift(index),
                )
                    : IconButton(
                  icon: const Icon(Icons.heart_broken, color: Colors.red),
                  onPressed: () => _pledgeGift(index),
                )
                    : giftStatus == 'pledged' && gift['pledgedBy'] == widget.currentUserId
                    ? const Icon(Icons.check, color: Colors.green) // Show checkmark if pledged by current user
                    : null,
              ),
            );
          },
        ),
      ),
      floatingActionButton: widget.userId == widget.currentUserId
          ? FloatingActionButton(
        onPressed: () => _showAddGiftDialog(context),
        tooltip: 'Add Gift',
        child: const Icon(Icons.add),
        backgroundColor: Colors.teal,
      )
          : null,
    );
  }
}
