import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'giftList.dart'; // Import the GiftScreen

class EventsPage extends StatelessWidget {
  final String userId;

  EventsPage({super.key, required this.userId});

  final TextEditingController _eventNameController = TextEditingController();
  final TextEditingController _eventDescriptionController = TextEditingController();
  final TextEditingController _eventLocationController = TextEditingController();
  final TextEditingController _eventDateController = TextEditingController();

  // Add a new event to Firestore
  void _addEvent(BuildContext context) async {
    final eventName = _eventNameController.text.trim();
    final eventDescription = _eventDescriptionController.text.trim();
    final eventLocation = _eventLocationController.text.trim();
    final eventDate = _eventDateController.text.trim();

    if (eventName.isEmpty || eventDescription.isEmpty || eventLocation.isEmpty || eventDate.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill in all fields.")),
      );
      return;
    }

    try {
      await FirebaseFirestore.instance.collection('users').doc(userId).update({
        'events': FieldValue.arrayUnion([{
          'eventName': eventName,
          'eventDescription': eventDescription,
          'eventLocation': eventLocation,
          'eventDate': eventDate,
          'gifts': [] // Initialize with an empty list of gifts
        }]),
      });

      _eventNameController.clear();
      _eventDescriptionController.clear();
      _eventLocationController.clear();
      _eventDateController.clear();

      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Event added successfully!")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  // Show a dialog to add a new event
  void _showAddEventDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text("Add Event"),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: _eventNameController,
                  decoration: const InputDecoration(labelText: 'Event Name'),
                ),
                TextField(
                  controller: _eventDescriptionController,
                  decoration: const InputDecoration(labelText: 'Event Description'),
                ),
                TextField(
                  controller: _eventLocationController,
                  decoration: const InputDecoration(labelText: 'Event Location'),
                ),
                TextField(
                  controller: _eventDateController,
                  decoration: const InputDecoration(labelText: 'Event Date (YYYY-MM-DD)'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () => _addEvent(context),
              child: const Text("Add Event"),
            ),
          ],
        );
      },
    );
  }

  // Edit Event
  void _editEvent(BuildContext context, int eventIndex) async {
    final eventRef = FirebaseFirestore.instance.collection('users').doc(userId);
    final eventSnapshot = await eventRef.get();
    final events = eventSnapshot.data()!['events'] as List<dynamic>;

    final event = events[eventIndex];

    _eventNameController.text = event['eventName'] ?? '';
    _eventDescriptionController.text = event['eventDescription'] ?? '';
    _eventLocationController.text = event['eventLocation'] ?? '';
    _eventDateController.text = event['eventDate'] ?? '';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text("Edit Event"),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: _eventNameController,
                  decoration: const InputDecoration(labelText: 'Event Name'),
                ),
                TextField(
                  controller: _eventDescriptionController,
                  decoration: const InputDecoration(labelText: 'Event Description'),
                ),
                TextField(
                  controller: _eventLocationController,
                  decoration: const InputDecoration(labelText: 'Event Location'),
                ),
                TextField(
                  controller: _eventDateController,
                  decoration: const InputDecoration(labelText: 'Event Date (YYYY-MM-DD)'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () async {
                final updatedEvent = {
                  'eventName': _eventNameController.text.trim(),
                  'eventDescription': _eventDescriptionController.text.trim(),
                  'eventLocation': _eventLocationController.text.trim(),
                  'eventDate': _eventDateController.text.trim(),
                  'gifts': event['gifts'],
                };

                try {
                  events[eventIndex] = updatedEvent;
                  await eventRef.update({'events': events});

                  _eventNameController.clear();
                  _eventDescriptionController.clear();
                  _eventLocationController.clear();
                  _eventDateController.clear();

                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Event updated successfully!")),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Error: $e")),
                  );
                }
              },
              child: const Text("Update Event"),
            ),
          ],
        );
      },
    );
  }

  // Delete Event
  void _deleteEvent(BuildContext context, int eventIndex) async {
    final eventRef = FirebaseFirestore.instance.collection('users').doc(userId);
    final eventSnapshot = await eventRef.get();
    final events = eventSnapshot.data()!['events'] as List<dynamic>;

    final event = events[eventIndex];
    final gifts = event['gifts'];

    // Check if any gift is pledged
    final isAnyGiftPledged = gifts.any((gift) => gift['isPledged'] == true);

    if (isAnyGiftPledged) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("This event cannot be deleted because at least one gift is pledged.")),
      );
      return;
    }

    events.removeAt(eventIndex);

    try {
      await eventRef.update({'events': events});
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Event deleted successfully!")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser == null) {
      return const Scaffold(
        body: Center(child: Text("No user is logged in.")),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Events"),
        backgroundColor: Colors.teal,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal, Colors.lightBlueAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance.collection('users').doc(userId).snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return const Center(child: Text("Error loading events."));
            }

            if (!snapshot.hasData || snapshot.data!['events'] == null) {
              return const Center(child: Text("No events available."));
            }

            final events = snapshot.data!['events'] as List<dynamic>;

            return ListView.builder(
              itemCount: events.length,
              itemBuilder: (context, index) {
                final event = events[index];
                final eventName = event['eventName'] ?? "No Name";
                final eventDescription = event['eventDescription'] ?? "No Description";
                final eventDate = event['eventDate'] ?? "No Date";
                final eventLocation = event['eventLocation'] ?? "No Location";
                final gifts = event['gifts'] ?? [];

                return Card(
                  margin: const EdgeInsets.all(10),
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: const BorderSide(color: Colors.teal, width: 2),
                  ),
                  child: ListTile(
                    leading: Icon(
                      Icons.event, // Default event icon
                      color: Colors.teal,
                    ),
                    title: Text(eventName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(eventDescription, style: const TextStyle(fontSize: 14)),
                        const SizedBox(height: 5),
                        Row(
                          children: [
                            Icon(Icons.calendar_today, size: 16, color: Colors.grey), // Calendar icon for date
                            const SizedBox(width: 5),
                            Text('Date: $eventDate', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          ],
                        ),
                        const SizedBox(height: 5),
                        Row(
                          children: [
                            Icon(Icons.location_on, size: 16, color: Colors.grey), // Location icon
                            const SizedBox(width: 5),
                            Text('Location: $eventLocation', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          ],
                        ),
                      ],
                    ),
                    trailing: currentUser.uid == userId
                        ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, color: Colors.teal),
                          onPressed: () => _editEvent(context, index),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteEvent(context, index),
                        ),
                      ],
                    )
                        : null,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => GiftScreen(
                            userId: userId,
                            currentUserId: currentUser.uid, // Pass the current user's ID
                            eventIndex: index,
                            gifts: gifts,
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            );
          },
        ),
      ),
      floatingActionButton: currentUser.uid == userId
          ? FloatingActionButton(
        onPressed: () => _showAddEventDialog(context),
        child: const Icon(Icons.add),
        backgroundColor: Colors.teal,
      )
          : null,
    );
  }
}
