import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

/// Default [FirebaseOptions] for use with your Firebase apps.
///
/// Example:
/// ```dart
/// import 'firebase_options.dart';
/// // ...
/// await Firebase.initializeApp(
///   options: DefaultFirebaseOptions.currentPlatform,
/// );
/// ```
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios; // Add iOS configuration if available
      case TargetPlatform.macOS:
        return macos; // Add macOS configuration if available
      case TargetPlatform.windows:
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for ${defaultTargetPlatform.name}. '
              'Run the FlutterFire CLI to configure Firebase for this platform.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // Web Firebase configuration
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDt1FJwuUHbPRkuWCenSwWDV8nhCo5p_qM',
    appId: '1:514039413626:web:0259fe184160f6723874c3',
    messagingSenderId: '514039413626',
    projectId: 'hediety-21ae7',
    authDomain: 'hediety-21ae7.firebaseapp.com',
    storageBucket: 'hediety-21ae7.appspot.com', // Corrected the domain
    measurementId: 'G-X8026N9V1G',
  );

  // Android Firebase configuration
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBwbyh86sKSPHSSN46vGaPeFgm0TOeiwEA',
    appId: '1:514039413626:android:f4c096dde97719823874c3',
    messagingSenderId: '514039413626',
    projectId: 'hediety-21ae7',
    storageBucket: 'hediety-21ae7.appspot.com', // Corrected the domain
  );

  // iOS Firebase configuration (if available)
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'YOUR_IOS_API_KEY',
    appId: 'YOUR_IOS_APP_ID',
    messagingSenderId: 'YOUR_IOS_MESSAGING_SENDER_ID',
    projectId: 'hediety-21ae7',
    storageBucket: 'hediety-21ae7.appspot.com',
    iosClientId: 'YOUR_IOS_CLIENT_ID',
    iosBundleId: 'YOUR_IOS_BUNDLE_ID',
  );

  // macOS Firebase configuration (optional)
  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'YOUR_MACOS_API_KEY',
    appId: 'YOUR_MACOS_APP_ID',
    messagingSenderId: 'YOUR_MACOS_MESSAGING_SENDER_ID',
    projectId: 'hediety-21ae7',
    storageBucket: 'hediety-21ae7.appspot.com',
    iosClientId: 'YOUR_MACOS_CLIENT_ID',
    iosBundleId: 'YOUR_MACOS_BUNDLE_ID',
  );
}
