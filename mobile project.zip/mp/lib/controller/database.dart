import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class GiftDatabase {
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await initDB();
    return _database!;
  }

  Future<Database> initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'gift_database.db');
    return await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE gifts(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT,
          description TEXT,
          category TEXT,
          price REAL,
          status TEXT,
          ownerId TEXT
        )
      ''');
    });
  }

  // Insert a gift
  Future<void> insertGift(Map<String, dynamic> gift) async {
    final db = await database;
    await db.insert('gifts', gift);
  }

  // Get all gifts
  Future<List<Map<String, dynamic>>> getAllGifts() async {
    final db = await database;
    return await db.query('gifts');
  }

  // Delete a gift
  Future<void> deleteGift(int id) async {
    final db = await database;
    await db.delete('gifts', where: 'id = ?', whereArgs: [id]);
  }
}
